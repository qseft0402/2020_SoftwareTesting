/**
 * Provides utility classes for geohashing in GeoHash and great circle navigation methods in Position.
 */
package com.github.davidmoten.geo;